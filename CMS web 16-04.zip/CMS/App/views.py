from datetime import datetime
import random
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from django.core.files.storage import FileSystemStorage
from django.db.models import Q
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect

from .invoice import genarate

# Create your views here.
from App.models import *

FS = FileSystemStorage()

STATIC_PATH = r"C:\Users\hridy\Music\CMS\App\static\\"


# from App.models import Department

def not_authenticated(request, type):
    if "lid" in request.session:
        obj = Login.objects.get(id=request.session['lid'])
        return False if obj.usertype == type else True
    return True


def default(request):
    return render(request, 'sign-in.html')


def login(request):
    return render(request, "sign-in.html")


def logout(request):
    request.session.clear()
    return redirect('/')


def loginpost(request):
    username = request.POST["username"]
    password = request.POST['password']
    res = Login.objects.filter(username=username, password=password)
    if res.exists():
        request.session['lid'] = res[0].id
        if res[0].usertype == 'admin':
            return redirect('/Admin_home')
        elif res[0].usertype == 'staff':
            return redirect('/staff_home')
        else:
            return HttpResponse("<script>alert('Invalid username');window.location='/'</script>")
    else:
        return HttpResponse("<script>alert('Login Failed ! ');window.location='/'</script>")


def admin_home(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    return render(request, "Admin/index.html")


def department_add(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    return render(request, "Admin/department_add.html")


def department_add_post(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    dept_name = request.POST["deptname"]
    dept_loc = request.POST['deptloc']
    if Department.objects.filter(name=dept_name).exists():
        return HttpResponse("<script>alert('Department already exist');window.location='/Admin_home'</script>")
    obj = Department()
    obj.name = dept_name
    obj.description = dept_loc
    obj.save()
    return HttpResponse("<script>alert('Successsfull');window.location='/Admin_home'</script>")


def view_department(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    data = Department.objects.all()
    return render(request, "Admin/department_view.html", {'data': data})


def update_department(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    data = Department.objects.get(id=id)
    return render(request, "Admin/department_update.html", {'data': data, 'id': id})


def update_department_post(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    dept_name = request.POST["deptname"]
    dept_loc = request.POST['deptloc']
    Department.objects.filter(id=id).update(dept_name=dept_name, dept_loc=dept_loc)
    return HttpResponse("<script>alert('updated Successsfully');window.location='/view_department'</script>")


def department_delete(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    Department.objects.filter(id=id).delete()
    return HttpResponse("<script>alert('Deleted Successsfully');window.location='/view_department'</script>")


def program_add(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    return render(request, "Admin/course_add.html", {'id': id})


def program_add_post(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    program_name = request.POST['coursename']
    strength = request.POST['strength']
    sem1 = request.POST['sem1']
    sem2 = request.POST['sem2']
    sem3 = request.POST['sem3']
    sem4 = request.POST['sem4']
    sem5 = request.POST['sem5']
    sem6 = request.POST['sem6']

    if (sem6 == "" and sem5 ==""):
        obj1 = Course()
        obj1.name = program_name
        obj1.sem1 = sem1
        obj1.sem2 = sem2
        obj1.sem3 = sem3
        obj1.sem4 = sem4
        obj1.sem5 = "pending"
        obj1.sem6 = "pending"
        obj1.strength = strength
        obj1.DEPARTMENT_id = id
        obj1.save()
        return HttpResponse("<script>alert('Course added Successsfully');window.location='/view_department'</script>")
    else:
        obj1 = Course()
        obj1.name = program_name
        obj1.sem1 = sem1
        obj1.sem2 = sem2
        obj1.sem3 = sem3
        obj1.sem4 = sem4
        obj1.sem5 = sem5
        obj1.sem6 = sem6
        obj1.strength = strength
        obj1.DEPARTMENT_id = id
        obj1.save()
        return HttpResponse("<script>alert('Course added Successsfully');window.location='/view_department'</script>")




def view_program(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    res = Course.objects.filter(DEPARTMENT=id)
    return render(request, 'Admin/program_view.html', {'data': res, "id": id})


def course_delete(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    Course.objects.filter(id=id).delete()
    return HttpResponse("<script>alert('deleted Successsfully');window.location='/view_department'</script>")


def add_staff(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    dep = Department.objects.all()
    return render(request, "Admin/Staff_add.html", {"dep": dep})


def add_staff_post(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    name = request.POST['name']
    email = request.POST['email']
    phone = request.POST['phone']
    place = request.POST['place']
    pin = request.POST['pin']
    post = request.POST['post']
    photo = request.FILES['photo']
    acc = request.POST['acc']
    ifsc = request.POST['ifsc']
    bank = request.POST['bank']
    dep = request.POST['department']
    d = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    FS.save(r"C:\Users\hridy\Music\CMS\App\static\image\\" + d + '.jpg', photo)
    path = "/static/image/" + d + '.jpg'

    p = random.randint(0000, 9999)
    i=Login.objects.filter(username=email)
    if i.exists():
        return HttpResponse("<script>alert('Username already existed');window.location='/add_staff'</script>")
    else:
        log = Login()
        log.username = email
        log.usertype = 'staff'
        log.password = p
        log.save()

        obj1 = Bank()
        obj1.accno = acc
        obj1.ifsc = ifsc
        obj1.bank = bank
        obj1.save()

        obj = Staff()
        obj.name = name
        obj.email = email
        obj.phone = phone
        obj.place = place
        obj.pin = pin
        obj.post = post
        obj.photo = path
        obj.LOGIN = log
        obj.BANK = obj1
        obj.DEPARTMENT_id = dep
        obj.save()

        import smtplib

        s = smtplib.SMTP(host='smtp.gmail.com', port=587)
        s.starttls()
        s.login("hridyahrz@gmail.com", "gabf vuku yrzt dpbd")
        msg = MIMEMultipart()  # create a message.........."
        msg['From'] = "hridyahrz@gmail.com"
        msg['To'] = email
        msg['Subject'] = "Your Password for CVCT"
        body = "Your Password is:- - " + str(p)
        msg.attach(MIMEText(body, 'plain'))
        s.send_message(msg)
        return HttpResponse("<script>alert('Staff added Successsfully');window.location='/Admin_home'</script>")


def staff_view(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    dep = Department.objects.all()
    d = ""
    if request.method == "POST":
        de = request.POST['dep']
        if de == "":
            d = de
            data = Staff.objects.all()
        else:
            d = int(de)
            data = Staff.objects.filter(DEPARTMENT=de)
        arr = []
        for i in data:
            allocated = ""
            q = Allocation.objects.filter(status="charge", STAFF=i.id)
            if q.exists():
                q = q[0]
                allocated = q.COURSE.name + " (" + q.BATCH.start_year + " to " + q.BATCH.end_year + ")"
            arr.append({"name": i.name,
                        "email": i.email,
                        "phone": i.phone,
                        "place": i.place,
                        "photo": i.photo,
                        "post": i.post,
                        "pin": i.pin,
                        "BANK": i.BANK,
                        "id": i.id,
                        "allocated": allocated})
        print(arr)
        return render(request, "Admin/Staff_view.html", {'data': arr, "dep": dep, "d": d})
    else:
        data = Staff.objects.all()
    arr = []
    for i in data:
        allocated = ""
        q = Allocation.objects.filter(status="charge", STAFF=i.id)
        if q.exists():
            q = q[0]
            allocated = q.COURSE.name + " (" + q.BATCH.start_year + " to " + q.BATCH.end_year + ")"
        arr.append({"name": i.name,
                    "email": i.email,
                    "phone": i.phone,
                    "place": i.place,
                    "photo": i.photo,
                    "post": i.post,
                    "pin": i.pin,
                    "BANK": i.BANK,
                    "id": i.id,
                    "allocated": allocated})
    print(arr)
    return render(request, "Admin/Staff_view.html", {'data': arr, "dep": dep, "d": d})


def staff_delete(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    Staff.objects.filter(id=id).delete()
    return HttpResponse("<script>alert('deleted Successsfully');window.location='/staff_view'</script>")


def update_staff(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    data = Staff.objects.get(id=id)
    return render(request, "Admin/Staff_update.html", {'data': data, 'id': id})


def update_staff_post(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    name = request.POST['name']
    email = request.POST['email']
    phone = request.POST['phone']
    place = request.POST['place']
    pin = request.POST['pin']
    post = request.POST['post']
    Staff.objects.filter(id=id).update(name=name, email=email, phone=phone, place=place, pin=pin, post=post)

    if "photo" in request.FILES:
        photo = request.FILES['photo']

        d = datetime.now().strftime("%Y%m%d-%H%M%S")
        FS.save(r"C:\Users\hridy\Music\CMS\App\static\image\\"+ d + '.jpg', photo)
        path = "/static/image/" + d + '.jpg'
        Staff.objects.filter(id=id).update(photo=path)
    return HttpResponse("<script>alert('updated Successsfully');window.location='/staff_view'</script>")


def batch_add(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    return render(request, "Admin/batch_add.html")


def batch_add_post(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    start = request.POST['startyear']
    end = request.POST['endyear']
    print(start)
    s = start.split('-')
    e = end.split('-')
    if Batch.objects.filter(start_year__iexact=s[0], end_year__iexact=e[0]).exists():
        return HttpResponse("<script>alert('This Batch is Already Exists');window.location='/batch_view'</script>")

    obj = Batch()
    obj.start_year = s[0]
    obj.end_year = e[0]
    obj.save()
    return HttpResponse("<script>alert('Batch added Successsfully');window.location='/batch_view'</script>")


def batch_view(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    data = Batch.objects.all()
    return render(request, "Admin/batch_view.html", {'data': data})


def batch_delete(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    Batch.objects.filter(id=id).delete()
    return HttpResponse("<script>alert('deleted Successsfully');window.location='/batch_view'</script>")


def student_add(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    data1 = Department.objects.all()
    date2 = Batch.objects.all()
    return render(request, "Admin/student_add.html", {'data1': data1, "data2": date2})


def list_course(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    obj = Course.objects.filter(DEPARTMENT=id)
    return render(request, 'admin/list_course.html', {"data": obj})


def student_add_post(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    name = request.POST['name']
    email = request.POST['email']
    phone = request.POST['phone']
    adhar = request.POST['adhar']
    place = request.POST['place']
    pin = request.POST['pin']
    post = request.POST['post']
    pname = request.POST['pgm']
    batch = request.POST['batch']
    photo = request.FILES['photo']
    data=Course.objects.get(id=pname)
    cout2 = 0
    fee = []
    if data.sem1 != 'pending':
        cout2+=1
    if data.sem2 != 'pending':
        cout2+=1
    if data.sem3 != 'pending':
        cout2+=1
    if data.sem4 != 'pending':
        cout2+=1
    if data.sem5 != 'pending':
        cout2+=1
    if data.sem6 != 'pending':
        cout2+=1

    d = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    FS.save(r"C:\Users\hridy\Music\CMS\App\static\image\\"+ d + '.jpg', photo)
    path = "/static/image/" + d + '.jpg'

    p = random.randint(0000, 9999)

    i=Login.objects.filter(username=email)
    if i.exists():
        return HttpResponse("<script>alert('Username  Already added');window.location='/student_add'</script>")
    else:
        log = Login()
        log.username = email
        log.usertype = 'student'
        log.password = p
        log.save()

        obj = Student()
        obj.name = name
        obj.email = email
        obj.phone = phone
        obj.adhar = adhar
        obj.place = place
        obj.pin = pin
        obj.post = post
        obj.BATCH_id = batch
        obj.COURSE_id = pname
        obj.Photo = path
        obj.LOGIN = log
        obj.save()
        print()

        for i in range(0,cout2):
            obj1=Fees()
            obj1.semester = str(i+1)+"sem"
            obj1.date = "0000-00-00"
            obj1.amount = "pending"
            obj1.STUDENT = obj
            obj1.save()

        import smtplib

        s = smtplib.SMTP(host='smtp.gmail.com', port=587)
        s.starttls()
        s.login("hridyahrz@gmail.com", "gabf vuku yrzt dpbd")
        msg = MIMEMultipart()  # create a message.........."
        msg['From'] = "hridyahrz@gmail.com"
        msg['To'] = email
        msg['Subject'] = "Your Password for CVCT"
        body = "Your Password is:- - " + str(p)
        msg.attach(MIMEText(body, 'plain'))
        s.send_message(msg)

        return HttpResponse("<script>alert('Student added Successsfully');window.location='/Admin_home'</script>")


def student_view(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    data = Student.objects.all()
    return render(request, "Admin/student_view.html", {'data': data})


def student_delete(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    Student.objects.filter(id=id).delete()
    return HttpResponse("<script>alert('deleted Successsfully');window.location='/student_view'</script>")


def update_student(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    data = Student.objects.get(id=id)
    data1 = Department.objects.all()
    data2 = Batch.objects.all()
    data3 = Course.objects.filter(id=data.COURSE_id)
    return render(request, "Admin/student_update.html", {'data': data, 'id': id, "dep": data1, "bat": data2, "cou": data3})


def update_student_post(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    try:
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        adhar = request.POST['adhar']
        place = request.POST['place']
        pin = request.POST['pin']
        post = request.POST['post']
        photo = request.FILES['photo']
        d = datetime.now().strftime("%Y%m%d-%H%M%S")
        FS = FileSystemStorage()
        FS.save(r"C:\Users\hridy\Music\CMS\App\static\image\\" + d + '.jpg', photo)
        path = "/static/image/" + d + '.jpg'
        Student.objects.filter(id=id).update(name=name, email=email, phone=phone, adhar=adhar, place=place, pin=pin,
                                             post=post, photo=path)
        return HttpResponse("<script>alert('updated Successsfully');window.location='/student_view'</script>")
    except Exception as e:
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        place = request.POST['place']
        pin = request.POST['pin']
        post = request.POST['post']
        Student.objects.filter(id=id).update(name=name, email=email, phone=phone, adhar=adhar, place=place, pin=pin,
                                             post=post)
        return HttpResponse("<script>alert('updated Successsfully');window.location='/student_view'</script>")


def batch_allocation(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    data = Batch.objects.all()
    return render(request, "Admin/batch_allocation.html", {'data': data, 'id': id})


def batch_allocation_post(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    # print(request.POST, "asdf")
    batch = request.POST['batch']
    Allocation.objects.filter(BATCH=batch, STAFF=id, status="normal").delete()
    depid = Staff.objects.get(id=id).DEPARTMENT_id
    obj = Course.objects.filter(DEPARTMENT=depid)
    for i in obj:
        n = "courses" + str(i.id)
        if n in request.POST:
            ob = Allocation()
            ob.BATCH_id = batch
            ob.STAFF_id = id
            ob.COURSE_id = i.id
            ob.status = "normal"
            ob.save()
    return HttpResponse("<script>alert('Batch allocated Successsfully');window.location='/staff_view'</script>")


def list_course_staff(request, bid, sid):
    arr = []
    depid = Staff.objects.get(id=sid).DEPARTMENT_id
    obj = Course.objects.filter(DEPARTMENT=depid)
    for i in obj:
        is_faculty = False
        in_charge = False
        q = Allocation.objects.filter(STAFF=sid, COURSE=i.id, BATCH=bid, status="normal")
        if q.exists():
            is_faculty = True
        q1 = Allocation.objects.filter(STAFF=sid, COURSE=i.id, BATCH=bid, status="charge")
        if q1.exists():
            in_charge = True

        arr.append({"name": i.name,
                    "id": i.id,
                    "is_faculty": is_faculty,
                    "is_in_charge": in_charge})
    context = {"data": arr, "bid": bid, "sid": sid}
    print(context)
    return render(request, 'admin/list_course_staff.html', context)


def set_incharge(request, cid, bid, sid):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    obj = Allocation.objects.filter(COURSE=cid, status="charge")
    if obj.exists():
        obj.delete()
    obj = Allocation()
    obj.STAFF_id = sid
    obj.BATCH_id = bid
    obj.COURSE_id = cid
    obj.status = "charge"
    obj.save()
    return HttpResponse("<script>alert('In Chrge Set Successfully');window.location='/staff_view'</script>")


def salary_add(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    return render(request, "Admin/salary_add.html", {'id': id})


def check_salary(request, id):
    sal = request.POST['sal']
    month = request.POST['month']
    if Salary.objects.filter(month=month, STAFF=id).exists():
        return HttpResponse("<script>alert('Already Added');window.location='/salary_add/" + str(id) + "'</script>")
    request.session['pay'] = sal
    request.session['month'] = month
    return redirect('/payment/' + id)


def payment(request, id):
    amount = float(request.session['pay']) * 100
    import razorpay

    razorpay_api_key = "rzp_test_MJOAVy77oMVaYv"
    razorpay_secret_key = "MvUZ03MPzLq3lkvMneYECQsk"

    razorpay_client = razorpay.Client(auth=(razorpay_api_key, razorpay_secret_key))

    # amount = float(amount)

    # Create a Razorpay order (you need to implement this based on your logic)
    order_data = {
        'amount': amount,
        'currency': 'INR',
        'receipt': 'order_rcptid_11',
        'payment_capture': '1',  # Auto-capture payment
    }

    # Create an order
    order = razorpay_client.order.create(data=order_data)

    context = {
        'razorpay_api_key': razorpay_api_key,
        'amount': order_data['amount'],
        'currency': order_data['currency'],
        'order_id': order['id'],
        "id": id,
    }

    return render(request, 'admin/payment.html', context)


def salary_add_post(request, id):
    sal = request.session['pay']
    month = request.session['month']
    obj = Salary()
    obj.amount = sal
    obj.month = month
    obj.STAFF_id = id
    obj.save()
    return HttpResponse("<script>alert('Salary added Successsfully');window.location='/staff_view'</script>")


def salary_view(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    data = Salary.objects.filter(STAFF_id=id)
    arr = []
    for i in data:
        arr.append({"amount": i.amount,
                    "pdate": i.date,
                    "date": i.month + " " + i.date.split('-')[0]})
    return render(request, "Admin/salary_view.html", {'data': arr, 'id': id})


def fee_add(request, id):
    return render(request, "Admin/fee_add.html", {'id': id})


def fee_add_post(request, id):
    fee = request.POST['fee2']
    data = Fees.objects.filter(PROGRAM_id=id)
    if data.exists():

        return HttpResponse("<script>alert('Fee Already added');window.location='/view_department'</script>")
    else:
        obj = Fees()
        obj.fee = fee
        obj.PROGRAM_id = id
        obj.save()
        return HttpResponse("<script>alert('Fee added Successsfully');window.location='/view_department'</script>")


def fee_view(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    data = Fees.objects.filter(PROGRAM_id=id)
    return render(request, "Admin/fee_view.html", {'data': data})


def staff_leave(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    data = Leave.objects.filter(LOGIN__usertype="staff", status="pending")
    arr = []
    for i in data:
        arr.append({"reason": i.reason,
                    "fromdate": i.fromdate,
                    "todate": i.todate,
                    "id": i.id,
                    "date": i.date,
                    "name": Staff.objects.get(LOGIN=i.LOGIN).name,
                    "dep": Staff.objects.get(LOGIN=i.LOGIN).DEPARTMENT.name})

    return render(request, "Admin/leave_request.html", {'data': arr})


def leave_approve(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    Leave.objects.filter(id=id).update(status='Approved')
    return HttpResponse("<script>alert('Approved');window.location='/Admin_home'</script>")


def leave_reject(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    Leave.objects.filter(id=id).update(status='Reject')
    return HttpResponse("<script>alert('Rejectd');window.location='/Admin_home'</script>")


def add_attendance(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    if datetime.datetime.today().weekday() > 5:
        return HttpResponse(
            "<script>alert('Cant Update Attendance on Weekends');window.location='/Admin_home'</script>")
    data = Department.objects.all()
    return render(request, "Admin/attendance_add.html", {'data': data})


def view_attendances(request, id):

    request.session['did'] = id
    data = Staff.objects.filter(DEPARTMENT=id)
    staffs = []
    if data.exists():
        staff = data[0]
        can_add = True
        if Attendance.objects.filter(LOGIN=staff.LOGIN, date=datetime.datetime.now().strftime("%Y-%m-%d")).exists():
            can_add = False
        if len(data) != 0:
            for i in data:
                att = ""
                ob = Attendance.objects.filter(LOGIN=i.LOGIN, date=datetime.datetime.now().strftime("%Y-%m-%d"))
                if ob.exists():
                    att = ob[0].attendance
                staffs.append({"name": i.name,
                               "phone": i.phone,
                               "att": att,
                               "id": i.id})

            return render(request, "admin/view_attendance_mark.html", {"data": staffs, "dep": id, "can_add": can_add})
        return render(request, "admin/view_attendance_mark.html", {"data": [], "dep": id, "can_add": False})
    return HttpResponse("")


def mark_attendance_post(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    obj = Staff.objects.filter(DEPARTMENT=id)
    for i in obj:
        status = request.POST[str(i.id)]
        obj = Attendance()
        obj.LOGIN_id = i.LOGIN_id
        obj.attendance = status
        obj.date = datetime.datetime.now().strftime("%Y-%m-%d")
        obj.save()
    return HttpResponse("<script>alert('Attendace added');window.location='/Admin_home'</script>")


def view_reports(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    obj = Fees.objects.all().order_by('-id')
    studarr = []
    arr = []
    for i in obj:
        if i.STUDENT_id not in studarr:
            studarr.append(i.STUDENT_id)
    for i in studarr:
        ob = Fees.objects.filter(STUDENT=i)
        arr.append({"STUDENT": ob[0].STUDENT,
                    "sem1": ob[0].date,
                    "sem2": ob[1].date,
                    "sem3": ob[2].date,
                    "sem4": ob[3].date,
                    "sem5": ob[4].date,
                    "sem6": ob[5].date,
                    })
    return render(request, 'admin/view_reports.html', {"data": arr})


def view_attendance(request):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    obj = Department.objects.all()
    return render(request, 'admin/view_attendance_staff.html', {"data": obj})


def view_attendance_staff_list(request, id):
    obj = Staff.objects.filter(DEPARTMENT=id)
    arr = []
    d = Attendance.objects.all()
    total_dates = []
    for i in d:
        if i.date not in total_dates:
            total_dates.append(i.date)

    if len(total_dates) >= 1:
        for i in obj:
            att = Attendance.objects.filter(LOGIN=i.LOGIN)
            count = 0
            for j in att:
                if j.attendance == "full":
                    count += 1
                else:
                    count += 0.5
            arr.append({"staff": i.name,
                        "attendance": count,
                        "id": i.LOGIN_id})
    return render(request, 'admin/list_attendance.html', {"data": arr, "days": len(total_dates)})


def view_more_attendance(request, id):
    if not_authenticated(request, "admin"):
        return redirect('/login')
    d = Attendance.objects.all()
    total_dates = []
    for i in d:
        if i.date not in total_dates:
            total_dates.append(i.date)

    if len(total_dates) >= 1:
        fd = datetime.datetime.strptime(total_dates[0], "%Y-%m-%d")
        td = datetime.datetime.strptime(datetime.datetime.now().strftime("%Y-%m-%d"), "%Y-%m-%d")
        arr = []
        dint = (td - fd).days
        for i in range(dint+1):
            d = datetime.datetime.now() - datetime.timedelta(days=i)
            if d.weekday() == 5:
                att = "Saturday-Holiday"
            elif d.weekday() == 6:
                att = "Sunday-Holiday"
            else:
                ob = Attendance.objects.filter(LOGIN=id, date=d.strftime("%Y-%m-%d"))
                if ob.exists():
                    if ob[0].attendance == 'absent':
                        att = "Absent"
                    else:
                        att = ob[0].attendance + " day"
                else:
                    att = "Didn't Updated Yet"

            arr.append({"date": d.strftime("%Y-%m-%d"),
                        "attendance": att})
        return render(request, "admin/view_more_attendance.html", {"data": arr})


def update_payment(request,id):
    cid=Student.objects.get(id=id).COURSE_id
    data1=Course.objects.get(id=cid)

    data = []
    i = Fees.objects.filter(Q(semester='1sem'), ~Q(date="0000-00-00"), Q(STUDENT_id=id))
    if i.exists():
        data.append({
            "amnt": data1.sem1,
            "sem": "1sem",
            "status": "paid",

        })
    else:
        data.append({
            "amnt": data1.sem1,
            "sem": "1sem",
            "status": "unpaid",
        })

    i = Fees.objects.filter(Q(semester='2sem'), ~Q(date="0000-00-00"), Q(STUDENT_id=id))
    if i.exists():
        data.append({
            "amnt": data1.sem2,
            "sem": "2sem",
            "status": "paid",
        })
    else:
        data.append({
            "amnt": data1.sem2,
            "sem": "2sem",
            "status": "unpaid"
        })

    i = Fees.objects.filter(Q(semester='3sem'), ~Q(date="0000-00-00"), Q(STUDENT_id=id))
    if i.exists():
        data.append({
            "amnt": data1.sem3,
            "sem": "3sem",
            "status": "paid"
        })
    else:
        data.append({
            "amnt": data1.sem3,
            "sem": "3sem",
            "status": "unpaid"
        })

    i = Fees.objects.filter(Q(semester='4sem'), ~Q(date="0000-00-00"), Q(STUDENT_id=id))
    if i.exists():
        data.append({
            "amnt": data1.sem4,
            "sem": "4sem",
            "status": "paid"
        })
    else:
        data.append({
            "amnt": data1.sem4,
            "sem": "4sem",
            "status": "unpaid"

        })

    i = Fees.objects.filter(Q(semester='5sem'), ~Q(date="0000-00-00"), Q(STUDENT_id=id))
    if i.exists():
        data.append({
            "amnt": data1.sem5,
            "sem": "5sem",
            "status": "paid"
        })
    else:
        data.append({
            "amnt": data1.sem5,
            "sem": "5sem",
            "status": "unpaid"
        })

    i = Fees.objects.filter(Q(semester='6sem'), ~Q(date="0000-00-00"), Q(STUDENT_id=id))
    if i.exists():
        data.append({
            "amnt": data1.sem6,
            "sem": "6sem",
            "status": "paid"
        })
    else:
        data.append({
            "amnt": data1.sem6,
            "sem": "6sem",
            "status": "unpaid"
        })

    return render(request,"Admin/view_payemnt.html",{"data":data,"id":id})


def pay_offline(request,id,sem):
    print(id,sem)
    Fees.objects.filter(STUDENT_id=id,semester=sem).update(date=datetime.datetime.now().strftime("%Y-%m-%d"))
    return HttpResponse("<script>alert('payment succesfull');window.location='/student_view'</script>")


# -------------------------------------Staff-----------------------------------------


def staff_home(request):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    obj = Staff.objects.get(LOGIN=request.session['lid'])
    request.session['name'] = obj.name
    request.session['photo'] = obj.photo
    return render(request, 'Staff/index.html')


def staff_view_profile(request):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    obj = Staff.objects.get(LOGIN=request.session['lid'])
    return render(request, 'Staff/view_profile.html', {"data": obj})


def staff_view_salary(request):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    obj = Salary.objects.filter(STAFF__LOGIN=request.session['lid'])
    return render(request, 'Staff/view_salary.html', {"data": obj})


def staff_view_attendance_report(request):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    d = Attendance.objects.all()
    total_dates = []
    for i in d:
        if i.date not in total_dates:
            total_dates.append(i.date)

    if len(total_dates) >= 1:
        fd = datetime.datetime.strptime(total_dates[0], "%Y-%m-%d")
        td = datetime.datetime.strptime(datetime.datetime.now().strftime("%Y-%m-%d"), "%Y-%m-%d")
        arr = []
        dint = (td - fd).days
        for i in range(dint + 1):
            d = datetime.datetime.now() - datetime.timedelta(days=i)
            if d.weekday() == 5:
                att = "Saturday-Holiday"
            elif d.weekday() == 6:
                att = "Sunday-Holiday"
            else:
                ob = Attendance.objects.filter(LOGIN=request.session['lid'], date=d.strftime("%Y-%m-%d"))
                if ob.exists():
                    if ob[0].attendance == 'absent':
                        att = "Absent"
                    else:
                        att = ob[0].attendance + " day"
                else:
                    att = "Didn't Updated Yet"

            arr.append({"date": d.strftime("%Y-%m-%d"),
                        "attendance": att})
        return render(request, 'Staff/view_attendance_report.html', {"data": arr})


def staff_send_leave_request(request):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    return render(request, 'Staff/send_leave_request.html')


def staff_send_leave_request_post(request):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    reason = request.POST['reason']
    fromdate = request.POST['fromdate']
    todate = request.POST['todate']
    obj = Leave()
    obj.date = datetime.datetime.now().strftime("%Y-%m-%d")
    obj.reason = reason
    obj.status = "pending"
    obj.fromdate = fromdate
    obj.todate = todate
    obj.LOGIN_id = request.session['lid']
    obj.save()
    return HttpResponse("<script>alert('Leave Request Sent Successfully');window.location='/staff_home'</script>")


def staff_view_leave_request_status(request):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    obj = Leave.objects.filter(LOGIN__usertype="staff").order_by('-id')
    return render(request, 'Staff/view_leave request_status.html', {"data": obj})


def staff_view_allocated_batch(request):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    obj = Allocation.objects.filter(STAFF__LOGIN=request.session['lid'])
    cid = []
    arr = []
    for i in obj:
        if i.COURSE_id not in cid:
            cid.append(i.COURSE_id)
            arr.append({"BATCH": i.BATCH,
                        "COURSE": i.COURSE})

    return render(request, 'Staff/view_allocated_batch.html', {"data": arr})


def staff_mark_attendance(request, bid, cid):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    obj = Student.objects.filter(BATCH=bid, COURSE=cid)
    arr = []
    if obj.exists():
        student = obj[0]
        can_add = True
        if Attendance.objects.filter(date=datetime.datetime.now().strftime("%Y-%m-%d"), LOGIN=student.LOGIN).exists():
            can_add = False
        for i in obj:
            att = ""
            ob = Attendance.objects.filter(LOGIN=i.LOGIN_id, date=datetime.datetime.now().strftime("%Y-%m-%d"))
            if ob.exists():
               att = ob[0].attendance
            arr.append({"name": i.name,
                        "adhar": i.adhar,
                        "phone": i.phone,
                        "email": i.email,
                        "Photo": i.Photo,
                        "place": i.place,
                        "post": i.post,
                        "pin": i.pin,
                        "id": i.id,
                        "LOGIN": i.LOGIN,
                        "att": att})
        return render(request, 'Staff/view_students.html', {"data": arr, "can_add": can_add, "bid": bid, "cid": cid})
    return render(request, 'Staff/view_students.html', {"data": [], "can_add": "no"})


def staff_mark_attendance_post(request, bid, cid):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    obj = Student.objects.filter(BATCH=bid, COURSE=cid)
    stud = obj[0]
    if Attendance.objects.filter(date=datetime.datetime.now().strftime("%Y-%m-%d"), LOGIN=stud.LOGIN).exists():
        return HttpResponse("<script>alert('Already Added');window.location='/staff_home'</script>")
    for i in obj:
        status = request.POST[str(i.LOGIN_id)]
        o = Attendance()
        o.LOGIN_id = i.LOGIN_id
        o.attendance = status
        o.date = datetime.datetime.now().strftime("%Y-%m-%d")
        o.save()
    return HttpResponse("<script>alert('Added Successfully');window.location='/staff_home'</script>")


def staff_view_leave_request(request):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    ob = Allocation.objects.filter(STAFF__LOGIN=request.session['lid'])
    students = []
    for i in ob:
        q = Student.objects.filter(COURSE=i.COURSE, BATCH=i.BATCH)
        for j in q:
            if j.LOGIN_id not in students:
                students.append(j.LOGIN_id)
    obj = Leave.objects.filter(LOGIN__in=students).order_by('-id')
    arr = []
    for i in obj:
        arr.append({"reason": i.reason,
                    "status": i.status,
                    "date": i.date,
                    "name": Student.objects.get(LOGIN=i.LOGIN).name,
                    "fromdate": i.fromdate,
                    "todate": i.todate,
                    "id": i.id})
    return render(request, 'Staff/view_leave_student_manage.html', {"data": arr})


def staff_leave_approve(request, id):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    Leave.objects.filter(id=id).update(status="approved")
    return HttpResponse("<script>alert('Approved Successfully');window.location='/staff_view_leave_request'</script>")


def staff_leave_reject(request, id):
    if not_authenticated(request, "staff"):
        return redirect('/login')
    Leave.objects.filter(id=id).update(status="rejected")
    return HttpResponse("<script>alert('Approved Successfully');window.location='/staff_view_leave_request'</script>")




###########################################USER##########################################################################


def and_login_user(request):
    uname=request.POST['username']
    pswd=request.POST['password']
    data=Login.objects.filter(username=uname,password=pswd,usertype="student")

    if data.exists():
        print("dfasg", data[0].id)
        return JsonResponse({"status":"ok","id":data[0].id})
    else:
        return JsonResponse({"status":"no"})

def and_view_profile(request):
    lid=request.POST['lid']
    print(lid)
    data=Student.objects.get(LOGIN=lid)
    print(data.Photo)
    return JsonResponse({"status":"ok","name":data.name,"email":data.email,"phone":data.phone,"aadhaar":data.adhar,"place":data.place,"pin":data.pin,"post":data.post,"course":data.COURSE.name,"batch1":data.BATCH.start_year,"batch2":data.BATCH.end_year,"image":data.Photo})


# def and_view_fee_details(request):
#     lid=request.POST['lid']
#     a = ["sem1","sem2" ,"sem3" ,"sem4", "sem5","sem6" ]
#     cid = Student.objects.get(LOGIN=lid).COURSE_id
#     for i in a:
#         res=Fees.objects.filter(STUDENT__LOGIN=lid, semester=i)
#         if res.exists():
#             pass
#         else:
#             if i == "sem1":
#                 fee = Course.objects.get(id=cid).sem1
#             elif i == "sem2":
#                 fee = Course.objects.get(id=cid).sem2
#             elif i == "sem3":
#                 fee = Course.objects.get(id=cid).sem3
#             elif i == "sem4":
#                 fee = Course.objects.get(id=cid).sem4
#             elif i == "sem5":
#                 fee = Course.objects.get(id=cid).sem5
#             elif i == "sem6":
#                 fee = Course.objects.get(id=cid).sem6
#
#             return JsonResponse({"status":"ok","fee":fee})


def and_view_fee_details(request):
    lid=request.POST['lid']
    sid=Student.objects.get(LOGIN_id=lid)
    cid=Student.objects.get(LOGIN=lid).COURSE_id
    data1=Course.objects.get(id=cid)

    data=[]
    i=Fees.objects.filter(Q(semester='1sem'),~Q(date="0000-00-00"),Q(STUDENT_id=sid))
    if i.exists():
        data.append({
            "amnt":data1.sem1,
            "sem":"1sem",
            "status":"paid",
            "pdf":i[0].pdf,

     })
    else:
        data.append({
            "amnt": data1.sem1,
            "sem": "1sem",
            "status": "unpaid",
            "pdf": "",
        })


    i=Fees.objects.filter(Q(semester='2sem'),~Q(date="0000-00-00"),Q(STUDENT_id=sid))
    if i.exists():
        data.append({
            "amnt": data1.sem2,
            "sem": "2sem",
            "status": "paid",
            "pdf": i[0].pdf,
        })
    else:
        data.append({
            "amnt": data1.sem2,
            "sem": "2sem",
            "status": "unpaid",
            "pdf": "",
        })


    i=Fees.objects.filter(Q(semester='3sem'),~Q(date="0000-00-00"),Q(STUDENT_id=sid))
    if i.exists():
        data.append({
            "amnt": data1.sem3,
            "sem": "3sem",
            "status": "paid",
            "pdf": i[0].pdf,
        })
    else:
        data.append({
            "amnt": data1.sem3,
            "sem": "3sem",
            "status": "unpaid",
            "pdf": "",
        })


    i=Fees.objects.filter(Q(semester='4sem'),~Q(date="0000-00-00"),Q(STUDENT_id=sid))
    if i.exists():
        data.append({
            "amnt": data1.sem4,
            "sem": "4sem",
            "status":"paid",
            "pdf": i[0].pdf,
        })
    else:
        data.append({
            "amnt": data1.sem4,
            "sem": "4sem",
            "status":"unpaid",
            "pdf": "",

        })

    i=Fees.objects.filter(Q(semester='5sem'),~Q(date="0000-00-00"),Q(STUDENT_id=sid))
    if i.exists():
        data.append({
            "amnt": data1.sem5,
            "sem": "5sem",
            "status":"paid",
            "pdf": i[0].pdf,
        })
    else:
        data.append({
            "amnt": data1.sem5,
            "sem": "5sem",
            "status": "unpaid",
            "pdf": "",
        })

    i=Fees.objects.filter(Q(semester='6sem'),~Q(date="0000-00-00"),Q(STUDENT_id=sid))
    if i.exists():
        data.append({
            "amnt": data1.sem6,
            "sem": "6sem",
            "status":"paid",
            "pdf": i[0].pdf,
        })
    else:
        data.append({
            "amnt": data1.sem6,
            "sem": "6sem",
            "status":"unpaid",
            "pdf": "",
        })

    print(data)

    return JsonResponse({"status":"ok","data":data})



def and_view_payment_history(request):
    lid=request.POST['lid']
    res=Fees.objects.filter(Q(STUDENT__LOGIN=lid),~Q(date="0000-00-00"))
    data=[]
    for i in res:
        data.append({
            "date":i.date,
            "sem":i.semester,
            "amount":i.amount
        })
    return JsonResponse({"status":"ok","data":data})


def and_send_leave_request(request):
    lid=request.POST['lid']
    rea=request.POST['reason']
    tod=request.POST['td']
    frd=request.POST['fd']
    obj=Leave()
    obj.LOGIN_id=lid
    obj.date=datetime.datetime.now().strftime("%Y-%m-%d")
    obj.reason=rea
    obj.todate=tod
    obj.fromdate=frd
    obj.status="pending"
    obj.save()
    return JsonResponse({"status":"ok"})

def and_view_request_status(request):
    lid=request.POST['lid']
    data=[]
    res=Leave.objects.filter(LOGIN_id=lid)
    for i in res:
        data.append(
            {
                "date":i.date,
                "reason":i.reason,
                "status":i.status,
                "to_date":i.todate,
                "from_date":i.fromdate,
            }
        )
    return JsonResponse({"status":"ok","data":data})


def and_view_attendance_report(request):
    lid=request.POST['lid']
    data=[]
    res=Attendance.objects.filter(LOGIN_id=lid)
    for i in res:
        data.append({
            "date":i.date,
            "attendance":i.attendance
        })
    return JsonResponse({"status":"ok","data":data})


def and_payment(request):
    lid=request.POST['lid']
    sem=request.POST['sem']
    amount=request.POST['amount']
    Stname = Student.objects.get(LOGIN=lid).name
    path = genarate(Stname, amount, sem)
    Fees.objects.filter(semester=sem,STUDENT__LOGIN_id=lid).update(date=datetime.datetime.now().strftime("%Y-%m-%d"),amount=amount, pdf=path)




    return JsonResponse({"status":"ok"})



def create_report(request):
    return render(request, 'admin/create_report.html')


def create_report_post(request):
    date = request.POST['date']

    from fpdf import FPDF
    from datetime import datetime

    # Create instance of FPDF class
    pdf = FPDF()
    pdf.add_page(

    )
    pdf.set_font("Arial", size=12)
    d = datetime.now().date()

    # Title
    pdf.cell(200, 10, txt=f"    Monthly Report                            Generated on {d}", ln=True, align="C")
    pdf.cell(200, 10, ln=True)

    pdf.cell(200, 10, txt="Staff Salary", ln=True, align="C")
    pdf.cell(200, 10, ln=True)

    obj = Salary.objects.filter(date__icontains=date)
    am = 0
    pdf.cell(200, 10, txt=f"------------------------------------------------------------", ln=True, align="L")
    for i in obj:
        am+=float(i.amount)
        pdf.cell(200, 10, txt=f"Staff: {i.STAFF.name}    -    {i.amount}", ln=True, align="L")
        pdf.cell(200, 10, txt=f"------------------------------------------------------------", ln=True, align="L")

    pdf.cell(200, 10, txt=f"Total Salary     ----- {am}", ln=True, align="C")
    pdf.cell(200, 10, ln=True)

    pdf.cell(200, 10, txt="Student Fees", ln=True, align="C")
    pdf.cell(200, 10, ln=True)

    obj = Fees.objects.filter(date__icontains=date)
    f = 0
    pdf.cell(200, 10, txt=f"------------------------------------------------------------", ln=True, align="L")
    for i in obj:
        f+=float(i.amount)
        pdf.cell(200, 10, txt=f"Student: {i.STUDENT.name}    -    {i.amount}", ln=True, align="L")
        pdf.cell(200, 10, txt=f"------------------------------------------------------------", ln=True, align="L")

    pdf.cell(200, 10, txt=f"Total Fees     ----- {f}", ln=True, align="C")
    pdf.cell(200, 10, txt="Student Fees", ln=True, align="C")
    pdf.cell(200, 10, ln=True)

    pdf.cell(200, 10, txt="Total Transactions Fees", ln=True, align="C")
    pdf.cell(200, 10, ln=True)
    pdf.cell(200, 10, txt=f"INCOME: {f}                      EXPENCES: {am}", ln=True, align="C")
    pdf.cell(200, 10, ln=True)



    # Save the PDF to file
    pdf.output(r"C:\Users\hridy\Music\CMS\App\static\reports\\" + "invoice.pdf")

    return redirect('/static/reports/invoice.pdf')

