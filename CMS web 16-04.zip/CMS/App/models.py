import datetime

from django.db import models


# Create your models here.

class Login(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    usertype = models.CharField(max_length=50)


class Department(models.Model):
    name = models.CharField(max_length=50)
    description = models.CharField(max_length=50)


class Course(models.Model):
    name = models.CharField(max_length=50)
    strength = models.CharField(max_length=50)
    sem1 = models.CharField(max_length=50)
    sem2 = models.CharField(max_length=50)
    sem3 = models.CharField(max_length=50)
    sem4 = models.CharField(max_length=50)
    sem5 = models.CharField(max_length=50)
    sem6 = models.CharField(max_length=50)
    DEPARTMENT = models.ForeignKey(Department, on_delete=models.CASCADE)


class Bank(models.Model):
    accno = models.CharField(max_length=50)
    ifsc = models.CharField(max_length=50)
    bank = models.CharField(max_length=50)
    amount = models.CharField(max_length=50)


class Staff(models.Model):
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    place = models.CharField(max_length=50)
    pin = models.CharField(max_length=50)
    post = models.CharField(max_length=50)
    photo = models.CharField(max_length=50)
    DEPARTMENT = models.ForeignKey(Department, on_delete=models.CASCADE)
    LOGIN = models.ForeignKey(Login, on_delete=models.CASCADE)
    BANK = models.ForeignKey(Bank, on_delete=models.CASCADE)


class Batch(models.Model):
    start_year = models.CharField(max_length=50)
    end_year = models.CharField(max_length=50)


class Allocation(models.Model):
    status = models.CharField(max_length=50)
    COURSE = models.ForeignKey(Course, on_delete=models.CASCADE)
    BATCH = models.ForeignKey(Batch, on_delete=models.CASCADE)
    STAFF = models.ForeignKey(Staff, on_delete=models.CASCADE)



class Salary(models.Model):
    amount = models.CharField(max_length=50)
    month = models.CharField(max_length=50)
    date = models.CharField(max_length=50, default=datetime.datetime.now().strftime("%Y-%m-%d"))
    STAFF = models.ForeignKey(Staff, on_delete=models.CASCADE)


class Student(models.Model):
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    adhar = models.CharField(max_length=50)
    place = models.CharField(max_length=50)
    pin = models.CharField(max_length=50)
    post = models.CharField(max_length=50)
    Photo = models.CharField(max_length=50)
    COURSE = models.ForeignKey(Course, on_delete=models.CASCADE)
    BATCH = models.ForeignKey(Batch, on_delete=models.CASCADE)
    LOGIN = models.ForeignKey(Login, on_delete=models.CASCADE)


class Fees(models.Model):
    semester = models.CharField(max_length=50)
    amount = models.CharField(max_length=50,default=1)
    date = models.CharField(max_length=50, default=datetime.datetime.now().strftime("%Y-%m-%d"))
    STUDENT = models.ForeignKey(Student, on_delete=models.CASCADE)
    pdf = models.CharField(max_length=70)


class Attendance(models.Model):
    date = models.CharField(max_length=50)
    attendance = models.CharField(max_length=50)
    LOGIN = models.ForeignKey(Login, on_delete=models.CASCADE)


class Leave(models.Model):
    date = models.CharField(max_length=50)
    fromdate = models.CharField(max_length=50)
    todate = models.CharField(max_length=50)
    reason = models.CharField(max_length=50)
    status = models.CharField(max_length=50)
    LOGIN = models.ForeignKey(Login, on_delete=models.CASCADE)


class Notification(models.Model):
    date = models.CharField(max_length=30)
    status = models.CharField(max_length=50)
    fromdate = models.CharField(max_length=50)
    todate = models.CharField(max_length=50)


class Payment(models.Model):
    date = models.CharField(max_length=50)
    semester = models.CharField(max_length=50)
    STUDENT = models.ForeignKey(Student, on_delete=models.CASCADE)

