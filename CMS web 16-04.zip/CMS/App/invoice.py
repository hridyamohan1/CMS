from fpdf import FPDF
from datetime import datetime
import random


def genarate(studentname, amount, semester):
    # Calculate total

    # Current date
    date = datetime.now()

    # Create instance of FPDF class
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    # Title
    pdf.cell(200, 10, txt="INVOICE", ln=True, align="C")
    pdf.cell(200, 10, ln=True)  # Empty line

    # Invoice details
    inv_number = random.randint(111111, 999999)
    pdf.cell(200, 10, txt=f"Invoice Number: {inv_number}", ln=True, align="L")
    pdf.cell(200, 10, txt=f"Date: {date.strftime('%Y-%m-%d %H:%M:%S')}", ln=True, align="L")
    pdf.cell(200, 10, txt=f"Student Name: {studentname}", ln=True, align="L")
    pdf.cell(200, 10, txt=f"Semester:  {semester}", ln=True, align="L")
    pdf.cell(200, 10, txt=f"Amount:  {amount}", ln=True, align="L")


    d = datetime.now().strftime("%Y%m%d%H%M%S")+".pdf"
    # Save the PDF to file
    pdf.output(r"C:\Users\hridy\Music\CMS\App\static\reports\\" + d)
    return "/static/reports/"+d