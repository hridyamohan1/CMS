"""CMS URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from App import views


urlpatterns = [
    path('', views.default),
    path('login',views.login),
    path('logout', views.logout),
    path('loginpost',views.loginpost),
    path('Admin_home',views.admin_home),
    path('department_add',views.department_add),
    path('department_add_post',views.department_add_post),
    path('program_add',views.program_add),
    path('program_add_post',views.program_add_post),
    path('view_department',views.view_department),
    path('update_department/<id>',views.update_department),
    path('update_department_post/<id>',views.update_department_post),
    path('department_delete/<id>',views.department_delete),
    path('program_add/<id>',views.program_add),
    path('program_add_post/<id>',views.program_add_post),
    path('view_program/<id>',views.view_program),
    path('course_delete/<id>',views.course_delete),
    path('add_staff',views.add_staff),
    path('add_staff_post',views.add_staff_post),
    path('staff_view',views.staff_view),
    path('batch_add',views.batch_add),
    path('batch_add_post',views.batch_add_post),
    path('batch_view',views.batch_view),
    path('batch_delete/<id>',views.batch_delete),
    path('staff_delete/<id>',views.staff_delete),
    path('update_staff/<id>',views.update_staff),
    path('update_staff_post/<id>',views.update_staff_post),
    path('student_add',views.student_add),
    path('student_add_post',views.student_add_post),
    path('student_view',views.student_view),
    path('student_delete/<id>',views.student_delete),
    path('update_student/<id>',views.update_student),
    path('update_student_post/<id>',views.update_student_post),
    path('batch_allocation/<id>',views.batch_allocation),
    path('batch_allocation_post/<id>',views.batch_allocation_post),
    path('salary_add/<id>',views.salary_add),
    path('salary_add_post/<id>',views.salary_add_post),
    path('salary_view/<id>',views.salary_view),
    path('fee_add/<id>',views.fee_add),
    path('fee_add_post/<id>',views.fee_add_post),
    path('fee_view/<id>',views.fee_view),
    path('staff_leave',views.staff_leave),
    path('leave_approve/<id>',views.leave_approve),
    path('leave_reject/<id>',views.leave_reject),
    path('add_attendance',views.add_attendance),
    path('mark_attendance_post/<id>',views.mark_attendance_post),
    path('view_attendances/<id>',views.view_attendances),
    path('list_course/<id>', views.list_course),
    path('check_salary/<id>', views.check_salary),
    path('payment/<id>', views.payment),
    path('list_course_staff/<bid>/<sid>', views.list_course_staff),
    path('set_incharge/<cid>/<bid>/<sid>', views.set_incharge),
    path('view_reports', views.view_reports),
    path('view_attendance', views.view_attendance),
    path('view_attendance_staff_list/<id>', views.view_attendance_staff_list),
    path('view_more_attendance/<id>', views.view_more_attendance),
    path('update_payment/<id>', views.update_payment),
    path('pay_offline/<id>/<sem>', views.pay_offline),

    path('staff_home', views.staff_home),
    path('staff_view_profile', views.staff_view_profile),
    path('staff_view_attendance_report', views.staff_view_attendance_report),
    path('staff_send_leave_request', views.staff_send_leave_request),
    path('staff_send_leave_request_post', views.staff_send_leave_request_post),
    path('staff_view_leave_request_status', views.staff_view_leave_request_status),
    path('staff_view_allocated_batch', views.staff_view_allocated_batch),
    path('staff_mark_attendance/<bid>/<cid>', views.staff_mark_attendance),
    path('staff_mark_attendance_post/<bid>/<cid>', views.staff_mark_attendance_post),
    path('staff_view_leave_request', views.staff_view_leave_request),
    path('staff_view_salary', views.staff_view_salary),
    path('staff_leave_approve/<id>', views.staff_leave_approve),
    path('staff_leave_reject/<id>', views.staff_leave_approve),

    path('and_login_user', views.and_login_user),
    path('and_view_profile', views.and_view_profile),
    path('and_view_fee_details', views.and_view_fee_details),
    path('and_view_payment_history', views.and_view_payment_history),
    path('and_send_leave_request', views.and_send_leave_request),
    path('and_view_request_status', views.and_view_request_status),
    path('and_view_attendance_report', views.and_view_attendance_report),
    path('and_view_payment_history', views.and_view_payment_history),
    path('and_view_payment_history', views.and_view_payment_history),
    path('and_payment', views.and_payment),
    path('create_report', views.create_report),
    path('create_report_post', views.create_report_post),






]

